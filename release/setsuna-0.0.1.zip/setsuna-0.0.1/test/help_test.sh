#!/bin/sh

java -jar setsuna.jar -help
java -jar setsuna.jar -h

