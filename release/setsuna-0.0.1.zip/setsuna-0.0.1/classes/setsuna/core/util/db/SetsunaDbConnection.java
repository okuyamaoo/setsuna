package setsuna.core.util.db;

import java.util.*;
import java.io.*;;
import java.sql.*;


public class SetsunaDbConnection {
}
